user_input = input("Enter a phrase: \n") #prompts user for input
print("Your phrase is: " + user_input) #This is an example of string
user_input = user_input.replace("agression", "aggression")
user_input = user_input.replace("pixle", "pixel")
user_input = user_input.replace("alot", "a lot")
user_input = user_input.replace("adress", "address")
print(user_input)
