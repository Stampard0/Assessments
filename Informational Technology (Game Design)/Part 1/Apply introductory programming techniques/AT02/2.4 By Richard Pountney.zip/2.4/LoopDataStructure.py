carlist = ["Toyota Camry", "Ford Falcon", "Nissan Pulsar", "Ferrari F50", "BMW M5"]
for x in carlist: #for every element in 'carlist' array
    print(x) #this prints each element in the list
