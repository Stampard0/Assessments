f = open("vehicles.txt", "r")
print(f.read())
f.close()
