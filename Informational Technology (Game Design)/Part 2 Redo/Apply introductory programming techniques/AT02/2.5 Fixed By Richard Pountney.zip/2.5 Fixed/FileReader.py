f = open("vehicles.txt", "r") #the r stands for read
print(f.read()) #this prints what it has read in the txt file
f.close() #it is good practice to close the file
