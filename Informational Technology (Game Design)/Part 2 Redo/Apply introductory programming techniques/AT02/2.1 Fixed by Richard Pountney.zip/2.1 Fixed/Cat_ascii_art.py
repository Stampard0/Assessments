print("""
      /\_/\ 
 /\  / o o \ 
//\\ \~(*)~/ 
`  \/   ^ / 
   | \|| ||  
   \ '|| ||  
    \)()-()) 
""") #using 3 speechmarks makes it so you can do multi line speech.
print("""
 /\_/\ 
( o o ) 
==_Y_== 
  `-' 
""")
