print("Hello World") #this makes the console print Hello World
